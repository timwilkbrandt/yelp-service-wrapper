﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

using Yelp.ServiceWrapper.Adapters;
using Yelp.ServiceWrapper.Requests;
using Yelp.ServiceWrapper.Models;

namespace Yelp.ServiceWrapper.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            var businessRequest = new BusinessRequest 
            {   
                ConsumerKey = ConfigurationManager.AppSettings["ConsumerKey"],
                ConsumerSecret = ConfigurationManager.AppSettings["ConsumerSecret"],
                Token = ConfigurationManager.AppSettings["Token"],
                TokenSecret = ConfigurationManager.AppSettings["TokenSecret"],
                BusinessId = "yelp-san-francisco"
            };

            using (var businessAdapter = new BusinessAdapter(businessRequest))
            {

                var response = businessAdapter.GetYelpBusinessResults();
                
                Console.WriteLine(response.Success);

                if(!response.Success)
                    Console.WriteLine(response.ErrorMessage);

                Console.WriteLine(response.YelpData);

                Console.ReadLine();

            }


            var searchRequest = new SearchRequest
            {

                ConsumerKey = ConfigurationManager.AppSettings["ConsumerKey"],
                ConsumerSecret = ConfigurationManager.AppSettings["ConsumerSecret"],
                Token = ConfigurationManager.AppSettings["Token"],
                TokenSecret = ConfigurationManager.AppSettings["TokenSecret"],
                Term = "hamburger"

       
            };

            searchRequest.Location = new Models.LocationModel { Address="Austin"};
            searchRequest.Location.CLL = new LocationCoordinates { Longitude = -97.74, Latitude = 30.26 };

            using (var searchAdapter = new SearchAdapter(searchRequest))
            {

                var response = searchAdapter.GetYelpSearchResults();

                Console.WriteLine(response.Success);

                if (!response.Success)
                    Console.WriteLine(response.ErrorMessage);

                Console.WriteLine(response.YelpData);

                Console.ReadLine();

            }        
        }
    }
}
