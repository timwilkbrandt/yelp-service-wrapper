﻿
namespace Yelp.ServiceWrapper.Responses
{
    /// <summary>
    /// SearchResponse: the search response object
    /// </summary>
    public class SearchResponse : BaseResponse
    {
    }
}
