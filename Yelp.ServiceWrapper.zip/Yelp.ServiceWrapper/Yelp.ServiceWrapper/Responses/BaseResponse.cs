﻿using Newtonsoft.Json.Linq;

namespace Yelp.ServiceWrapper.Responses
{

    /// <summary>
    /// BaseResponse: the base response object
    /// </summary>
    public class BaseResponse
    {

        /// <summary>
        /// Success: bool, indicating the state of the transaction
        /// </summary>
        public bool Success { get; set; }


        /// <summary>
        /// ErrorMessage: string, the error message that occurs during the Yelp Service call
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// YelpData: Json data returned from Yelp
        /// </summary>
        public JObject YelpData { get; set; } 
    }

}
