﻿
namespace Yelp.ServiceWrapper.Responses
{

    /// <summary>
    /// BusinessResponse: the business response object
    /// </summary>
    public class BusinessResponse : BaseResponse
    {
    }
}
