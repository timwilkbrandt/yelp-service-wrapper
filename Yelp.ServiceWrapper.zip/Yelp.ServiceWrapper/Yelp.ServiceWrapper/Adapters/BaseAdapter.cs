﻿using System;
using System.Net;
using System.Web;
using System.IO;
using System.Text;

using SimpleOAuth;
using Newtonsoft.Json.Linq;

using Yelp.ServiceWrapper.Requests;
using Yelp.ServiceWrapper.Responses;
using Yelp.ServiceWrapper.Constants;

namespace Yelp.ServiceWrapper.Adapters
{

    /// <summary>
    /// BaseAdapter: Generates WebRequest and WebResponse
    /// </summary>
    public abstract class BaseAdapter : IDisposable
    {

        private BaseRequest _request;

        /// <summary>
        /// Constructor: intializes the _request object.
        /// </summary>
        /// <param name="request"></param>
        protected BaseAdapter(BaseRequest request)
        {
            _request = request;
        }

        /// <summary>
        /// CallYelp: calls the Yelp Web API v2
        /// </summary>
        /// <param name="apiPath">string: the selected api path</param>
        /// <returns>JObject: JSON object returned from the Yelp Web API</returns>
        protected JObject CallYelp(string apiPath)
        {

            var query = System.Web.HttpUtility.ParseQueryString(String.Empty);
           
            //Build the QueryString
            foreach (var queryParam in _request.QueryParameters)
            {
                query[queryParam.Key] = queryParam.Value;
            };


            var uriBuilder = new UriBuilder(string.Format("{0}{1}", ApiConfigurationSettings.ApiHost, apiPath));
            uriBuilder.Query = query.ToString();

            //Create the REST based requet to Yelp
            var yelpRequest = WebRequest.Create(uriBuilder.ToString());
            yelpRequest.Method = "GET";
            yelpRequest.SignRequest(
                new Tokens
                {
                    ConsumerKey = _request.ConsumerKey,
                    ConsumerSecret = _request.ConsumerSecret,
                    AccessToken = _request.Token,
                    AccessTokenSecret = _request.TokenSecret
                }
            ).WithEncryption(EncryptionMethod.HMACSHA1).InHeader();

            //Generate the respone from Yelp
            var response = (HttpWebResponse)yelpRequest.GetResponse();
            var stream = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
            
            return JObject.Parse(stream.ReadToEnd());           

        }

        /// <summary>
        /// Dispose: dispose method
        /// </summary>
        public void Dispose()
        {

        }
    }
}
