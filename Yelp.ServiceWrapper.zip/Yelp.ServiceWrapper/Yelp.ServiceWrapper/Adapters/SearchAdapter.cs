﻿using System.Linq;

using Yelp.ServiceWrapper.Requests;
using Yelp.ServiceWrapper.Responses;
using Yelp.ServiceWrapper.Constants;


namespace Yelp.ServiceWrapper.Adapters
{
    /// <summary>
    /// SearchAdapter: specific to the Yelp Search Web API
    /// </summary>
    public class SearchAdapter : BaseAdapter
    {

        /// <summary>
        /// Constructor: builds the query string parameter for the request
        /// </summary>
        /// <param name="request"></param>
        public SearchAdapter(SearchRequest request) : base(request)
        {
            if(request.GeoCoordinates != null)
            {
                var param = request.GeoCoordinates.CreateQueryStringParamter();

                request.QueryParameters.Add(param.Keys.First(), param.Values.First());
            }

            if (request.Bounds != null)
            {
                var param = request.Bounds.CreateQueryStringParamter();

                request.QueryParameters.Add(param.Keys.First(), param.Values.First());
            }


            if (request.Location != null)
            {

                if(!string.IsNullOrEmpty(request.Location.Address))
                    request.QueryParameters.Add("location", request.Location.Address);

                if(request.Location.CLL != null)
                {
                    var cllParam = request.Location.CLL.CreateQueryStringParamter();

                    request.QueryParameters.Add(cllParam.Keys.First(), cllParam.Values.First());
                }
            }


        }

        /// <summary>
        /// GetYelpSearchResults: Gets the results from the Yelp Search Web API
        /// </summary>
        /// <returns>BaseResponse: the response object</returns>
        public BaseResponse GetYelpSearchResults()
        {

            var response = new BaseResponse { Success = true };

            try
            {

                var yelpResponse = base.CallYelp(ApiConfigurationSettings.SearchPath);

                response.YelpData = yelpResponse;

            }
            catch (System.Exception ex)
            {

                response.Success = false;
                response.ErrorMessage = ex.Message;

            }

            return response;
        }

    }
}
