﻿using Yelp.ServiceWrapper.Requests;
using Yelp.ServiceWrapper.Responses;
using Yelp.ServiceWrapper.Constants;

namespace Yelp.ServiceWrapper.Adapters
{

    /// <summary>
    /// BusinessAdapter: specific to the Yelp Business Web API
    /// </summary>
    public class BusinessAdapter : BaseAdapter
    {
        private string _businessId;

        /// <summary>
        /// Constructor: intializes the _businessId object.
        /// </summary>
        /// <param name="request"></param>
        public BusinessAdapter(BusinessRequest request) : base(request)
        {
            _businessId = request.BusinessId;
        }

        /// <summary>
        /// GetYelpBusinessResults: Gets the results from the Yelp Business Web API
        /// </summary>
        /// <returns>BaseResponse: the response object</returns>
        public BaseResponse GetYelpBusinessResults()
        {

            var response = new BaseResponse { Success = true };

            try
            {

                var yelpResponse = base.CallYelp(string.Format("{0}/{1}", ApiConfigurationSettings.BusinessPath, _businessId));

                response.YelpData = yelpResponse;

            }
            catch (System.Exception ex)
            {

                response.Success = false;
                response.ErrorMessage = ex.Message;

            }

            return response;
        }
    }
}
