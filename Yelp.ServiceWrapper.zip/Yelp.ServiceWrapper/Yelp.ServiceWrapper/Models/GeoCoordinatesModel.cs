﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yelp.ServiceWrapper.Models
{

    /// <summary>
    /// ll=latitude,longitude,accuracy,altitude,altitude_accuracy
    /// </summary>
    public partial class GeoCoordinatesModel
    {
        public double LL_Latitude { get; set; }
        public double LL_Longitude { get; set; }
        public double LL_Accuracy { get; set; }
        public double LL_Altitude { get; set; }
        public double LL_AltitudeAccuracy { get; set; }
    }

    public partial class GeoCoordinatesModel
    {

        /// <summary>
        /// CreateQueryStringParamter: Creates a querystring parameter
        /// </summary>
        /// <returns>Dictionary: the key value pair of the querystring porameter</returns>
        public Dictionary<string, string> CreateQueryStringParamter()
        {

            var qsVal = string.Format("{0},{1},{2},{3},{4}", LL_Altitude, LL_Longitude, LL_Accuracy, LL_Altitude, LL_AltitudeAccuracy);
            var dictionary = new Dictionary<string, string>();
            dictionary.Add("ll", qsVal);
            return dictionary;
             
        }
    }
}
