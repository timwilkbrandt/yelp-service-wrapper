﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yelp.ServiceWrapper.Models
{

    //location=address
    public partial class LocationModel
    {
        public LocationCoordinates CLL { get; set; }
        
        /// <summary>
        /// Specifies the combination of "address, neighborhood, city, state or zip, optional country" to be used when searching for businesses.
        /// </summary>
        public string Address { get; set; }
    }

    /// <summary>
    /// cll=latitude,longitude
    /// </summary>
    public partial class LocationCoordinates
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }

    public partial class LocationCoordinates
    {

        /// <summary>
        /// CreateQueryStringParamter: Creates a querystring parameter
        /// </summary>
        /// <returns>Dictionary: the key value pair of the querystring porameter</returns>
        public Dictionary<string, string> CreateQueryStringParamter()
        {

            var qsVal = string.Format("{0},{1}", Latitude, Longitude);
            var dictionary = new Dictionary<string, string>();
            dictionary.Add("cll", qsVal);
            return dictionary;

        }
    }
}
