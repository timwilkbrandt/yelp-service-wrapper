﻿using System.Collections.Generic;

namespace Yelp.ServiceWrapper.Requests
{

    /// <summary>
    /// BaseRequest: the base request object
    /// </summary>
    public class BaseRequest
    {

        /// <summary>
        /// Constructor: initializes the QueryParametrs object
        /// </summary>
        public BaseRequest()
        {
            QueryParameters = new Dictionary<string, string>();
        }

        /// <summary>
        /// ConsumerSecret: string, Yelp account configuration setting: ConsumerSecret.
        /// </summary>
        public string ConsumerSecret { get; set; }

        /// <summary>
        /// ConsumerKey: string, Yelp account configuration setting: ConsumerKey.
        /// </summary>
        public string ConsumerKey { get; set; }

        /// <summary>
        /// Token: string, Yelp account configuration setting: Token.
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        /// TokenSecret: string, Yelp account configuration setting: TokenSecret.
        /// </summary>
        public string TokenSecret { get; set; }

        /// <summary>
        /// QueryParameters: Dictionary, key values pairs of the QueryString parameters.
        /// </summary>
        public Dictionary<string, string> QueryParameters { get; set; }

    }

}
