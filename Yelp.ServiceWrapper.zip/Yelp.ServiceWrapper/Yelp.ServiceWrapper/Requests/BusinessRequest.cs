﻿
namespace Yelp.ServiceWrapper.Requests
{

    /// <summary>
    /// BusinessRequest: the Yelp Web API Business Request object
    /// </summary>
    public class BusinessRequest : BaseRequest
    {
        /// <summary>
        /// BusinessId: string, the id of the business (usually obtained via a Search Request)
        /// </summary>
        public string BusinessId { get; set; }
    }
}
