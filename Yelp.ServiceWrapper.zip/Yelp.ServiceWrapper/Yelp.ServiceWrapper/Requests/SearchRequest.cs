﻿using Yelp.ServiceWrapper.Models;

namespace Yelp.ServiceWrapper.Requests
{

    /// <summary>
    /// SearchRequest: the Yelp Web API Search Request object
    /// </summary>
    public class SearchRequest : BaseRequest
    {

        /// <summary>
        /// Term: Search term (e.g. "food", "restaurants"). If term isn’t included we search everything.
        /// </summary>
        public string Term { set { QueryParameters.Add("term", value); } }
        
        /// <summary>
        /// Limit: Number of business results to return
        /// </summary>
        public int Limit { set { QueryParameters.Add("limit", value.ToString()); } }

        /// <summary>
        /// Offset: Offset the list of returned business results by this amount
        /// </summary>
        public int OffSet { set { QueryParameters.Add("offdset", value.ToString()); } }

        /// <summary>
        /// Sort: Sort mode: 0=Best matched (default), 1=Distance, 2=Highest Rated
        /// </summary>
        public int Sort {  set { QueryParameters.Add("sort", value.ToString()); } }

        /// <summary>
        /// CategoryFilter: see https://www.yelp.com/developers/documentation/v2/all_category_list
        /// </summary>
        public string CategoryFilter { set { QueryParameters.Add("category_filter", value); } }

        /// <summary>
        /// RadiusFilter:  Search radius in meters. If the value is too large, a AREA_TOO_LARGE error may be returned. The max value is 40000 meters (25 miles).
        /// </summary>
        public int RadiusFilter { set { QueryParameters.Add("radius_filter", value.ToString()); } }

        /// <summary>
        /// CC: country code, see http://en.wikipedia.org/wiki/ISO_3166-1_alpha-2
        /// </summary>
        public string CC {  set { QueryParameters.Add("cc", value); }}

        /// <summary>
        /// Lang: language, see http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
        /// </summary>
        public string Lang { set { QueryParameters.Add("lang", value); } }

        /// <summary>
        /// DealsFilter: bool, Whether to exclusively search for businesses with deals
        /// </summary>
        public bool? DealsFilter
        {
            get { return DealsFilter; }
            set
            {

                if (value != null) { { QueryParameters.Add("deals_filter", value.ToString()); } }
            }


        }

        /// <summary>
        /// GeoCoordinatesModel: contains querystring parmaters related to GeoCoordinates
        /// </summary>
        public GeoCoordinatesModel GeoCoordinates { get; set; }

        /// <summary>
        /// LocationModel: contains querystring parmaters related to Location
        /// </summary>
        public LocationModel Location { get; set; }

        /// <summary>
        /// Bounds: contains querystring parmaters related to Bounds
        /// </summary>
        public BoundsModel Bounds { get; set; }
    }
}
