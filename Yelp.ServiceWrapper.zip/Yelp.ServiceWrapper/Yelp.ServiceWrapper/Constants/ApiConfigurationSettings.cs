﻿
namespace Yelp.ServiceWrapper.Constants
{

    /// <summary>
    /// ApiConfigurationSettings: Yelp specific constants
    /// </summary>
    public class ApiConfigurationSettings
    {
        public const string ApiHost = "http://api.yelp.com";

        public const string SearchPath = "/v2/search";

        public const string BusinessPath = "/v2/business";
    }
}
