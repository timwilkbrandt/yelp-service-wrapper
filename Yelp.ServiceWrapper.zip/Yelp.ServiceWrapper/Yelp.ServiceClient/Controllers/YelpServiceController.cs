﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Yelp.ServiceClient.Controllers
{
    public class YelpServiceController : Controller
    {
        //
        // GET: /YelpService/

        public ActionResult Index()
        {
            return View();
        }

    }
}
